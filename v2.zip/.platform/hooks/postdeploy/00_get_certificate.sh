#!/usr/bin/env bash
sudo certbot -n -d 3-1.intex.is404.net --nginx --agree-tos --email tcdavis@byu.edu
sudo certbot -n -d 3-1intex.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email tcdavis@byu.edu