let express = require("express");

let app = express();

let path = require("path");

let security = false;

const port = process.env.PORT || 5500;

app.set("view engine", "ejs");

app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({extended: true})); // Makes it so the server can get the stuff out of the form //Id is for DOM, Name is for the server

app.use(express.static('public')); // Enabling public folder for css

// Connect the knex library
const knex = require("knex") ({
    client : "pg",
    connection : {
        host : process.env.RDS_HOSTNAME || "localhost",
        user : process.env.RDS_USERNAME || "postgres",
        password : process.env.RDS_PASSWORD || "POS921pos@",
        database : process.env.RDS_DB_NAME || "disneycharacters",
        port : process.env.RDS_PORT || 5432,
        ssl: process.env.DB_SSL ? {rejectUnauthorized: false} : false
    }
})

// Route to display disneycharacter records
app.get('/', (req, res) => {
    knex('character')
        .join('movie', 'movie.movie_id', '=', 'character.movie_id')
        .select(
            'character.character_id',
            'character.character_name',
            'character.movie_id',
            'character.eye_color',
            'movie.movie_id',
            'movie.movie_name',
            'movie.movie_category'
        )
        .orderBy('character.character_name')
        .then(disneycharacter => {
            // Render the index.ejs template and pass the data
            res.render('index', { disneycharacter, security });
        })
        .catch(error => {
            console.error('Error querying database:', error);
            res.status(500).send('Internal Server Error');
        });
    });

// Shows server is listening on start up
app.listen(port, () => console.log("Listening..."));